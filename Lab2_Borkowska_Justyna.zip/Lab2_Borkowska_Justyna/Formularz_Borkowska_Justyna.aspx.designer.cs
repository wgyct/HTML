﻿//------------------------------------------------------------------------------
// <generowane automatycznie>
//     Ten kod został wygenerowany przez narzędzie.
//
//     Zmiany w tym pliku mogą spowodować niewłaściwe zachowanie i zostaną utracone
//     w przypadku ponownego wygenerowania kodu. 
// </generowane automatycznie>
//------------------------------------------------------------------------------

namespace Lab1_Borkowska_Justyna
{


    public partial class Formularz_Borkowska_Justyna
    {

        /// <summary>
        /// Kontrolka form1.
        /// </summary>
        /// <remarks>
        /// Pole generowane automatycznie.
        /// Aby wprowadzić zmiany, przenieś deklarację pola z pliku projektanta do pliku codebehind.
        /// </remarks>
        protected global::System.Web.UI.HtmlControls.HtmlForm form1;

        /// <summary>
        /// Kontrolka ScriptManager1.
        /// </summary>
        /// <remarks>
        /// Pole generowane automatycznie.
        /// Aby wprowadzić zmiany, przenieś deklarację pola z pliku projektanta do pliku codebehind.
        /// </remarks>
        protected global::System.Web.UI.ScriptManager ScriptManager1;

        /// <summary>
        /// Kontrolka Panel1.
        /// </summary>
        /// <remarks>
        /// Pole generowane automatycznie.
        /// Aby wprowadzić zmiany, przenieś deklarację pola z pliku projektanta do pliku codebehind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.Panel Panel1;

        /// <summary>
        /// Kontrolka Label4.
        /// </summary>
        /// <remarks>
        /// Pole generowane automatycznie.
        /// Aby wprowadzić zmiany, przenieś deklarację pola z pliku projektanta do pliku codebehind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.Label Label4;

        /// <summary>
        /// Kontrolka Label1.
        /// </summary>
        /// <remarks>
        /// Pole generowane automatycznie.
        /// Aby wprowadzić zmiany, przenieś deklarację pola z pliku projektanta do pliku codebehind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.Label Label1;

        /// <summary>
        /// Kontrolka RadioButtonList1.
        /// </summary>
        /// <remarks>
        /// Pole generowane automatycznie.
        /// Aby wprowadzić zmiany, przenieś deklarację pola z pliku projektanta do pliku codebehind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.RadioButtonList RadioButtonList1;

        /// <summary>
        /// Kontrolka Label2.
        /// </summary>
        /// <remarks>
        /// Pole generowane automatycznie.
        /// Aby wprowadzić zmiany, przenieś deklarację pola z pliku projektanta do pliku codebehind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.Label Label2;

        /// <summary>
        /// Kontrolka DropDownList1.
        /// </summary>
        /// <remarks>
        /// Pole generowane automatycznie.
        /// Aby wprowadzić zmiany, przenieś deklarację pola z pliku projektanta do pliku codebehind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.DropDownList DropDownList1;

        /// <summary>
        /// Kontrolka Label3.
        /// </summary>
        /// <remarks>
        /// Pole generowane automatycznie.
        /// Aby wprowadzić zmiany, przenieś deklarację pola z pliku projektanta do pliku codebehind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.Label Label3;

        /// <summary>
        /// Kontrolka DropDownList2.
        /// </summary>
        /// <remarks>
        /// Pole generowane automatycznie.
        /// Aby wprowadzić zmiany, przenieś deklarację pola z pliku projektanta do pliku codebehind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.DropDownList DropDownList2;

        /// <summary>
        /// Kontrolka data.
        /// </summary>
        /// <remarks>
        /// Pole generowane automatycznie.
        /// Aby wprowadzić zmiany, przenieś deklarację pola z pliku projektanta do pliku codebehind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.Label data;

        /// <summary>
        /// Kontrolka data2.
        /// </summary>
        /// <remarks>
        /// Pole generowane automatycznie.
        /// Aby wprowadzić zmiany, przenieś deklarację pola z pliku projektanta do pliku codebehind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.Label data2;

        /// <summary>
        /// Kontrolka godzina.
        /// </summary>
        /// <remarks>
        /// Pole generowane automatycznie.
        /// Aby wprowadzić zmiany, przenieś deklarację pola z pliku projektanta do pliku codebehind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.Label godzina;

        /// <summary>
        /// Kontrolka godzina2.
        /// </summary>
        /// <remarks>
        /// Pole generowane automatycznie.
        /// Aby wprowadzić zmiany, przenieś deklarację pola z pliku projektanta do pliku codebehind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.Label godzina2;

        /// <summary>
        /// Kontrolka uzyt.
        /// </summary>
        /// <remarks>
        /// Pole generowane automatycznie.
        /// Aby wprowadzić zmiany, przenieś deklarację pola z pliku projektanta do pliku codebehind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.Label uzyt;

        /// <summary>
        /// Kontrolka uzyt2.
        /// </summary>
        /// <remarks>
        /// Pole generowane automatycznie.
        /// Aby wprowadzić zmiany, przenieś deklarację pola z pliku projektanta do pliku codebehind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.Label uzyt2;

        /// <summary>
        /// Kontrolka roz.
        /// </summary>
        /// <remarks>
        /// Pole generowane automatycznie.
        /// Aby wprowadzić zmiany, przenieś deklarację pola z pliku projektanta do pliku codebehind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.Label roz;

        /// <summary>
        /// Kontrolka roz2.
        /// </summary>
        /// <remarks>
        /// Pole generowane automatycznie.
        /// Aby wprowadzić zmiany, przenieś deklarację pola z pliku projektanta do pliku codebehind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.Label roz2;

        /// <summary>
        /// Kontrolka ukl.
        /// </summary>
        /// <remarks>
        /// Pole generowane automatycznie.
        /// Aby wprowadzić zmiany, przenieś deklarację pola z pliku projektanta do pliku codebehind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.Label ukl;

        /// <summary>
        /// Kontrolka ukl2.
        /// </summary>
        /// <remarks>
        /// Pole generowane automatycznie.
        /// Aby wprowadzić zmiany, przenieś deklarację pola z pliku projektanta do pliku codebehind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.Label ukl2;

        /// <summary>
        /// Kontrolka Image1.
        /// </summary>
        /// <remarks>
        /// Pole generowane automatycznie.
        /// Aby wprowadzić zmiany, przenieś deklarację pola z pliku projektanta do pliku codebehind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.Image Image1;

        /// <summary>
        /// Kontrolka Image2.
        /// </summary>
        /// <remarks>
        /// Pole generowane automatycznie.
        /// Aby wprowadzić zmiany, przenieś deklarację pola z pliku projektanta do pliku codebehind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.Image Image2;

        /// <summary>
        /// Kontrolka Image3.
        /// </summary>
        /// <remarks>
        /// Pole generowane automatycznie.
        /// Aby wprowadzić zmiany, przenieś deklarację pola z pliku projektanta do pliku codebehind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.Image Image3;

        /// <summary>
        /// Kontrolka Image4.
        /// </summary>
        /// <remarks>
        /// Pole generowane automatycznie.
        /// Aby wprowadzić zmiany, przenieś deklarację pola z pliku projektanta do pliku codebehind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.Image Image4;

        /// <summary>
        /// Kontrolka Image5.
        /// </summary>
        /// <remarks>
        /// Pole generowane automatycznie.
        /// Aby wprowadzić zmiany, przenieś deklarację pola z pliku projektanta do pliku codebehind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.Image Image5;

        /// <summary>
        /// Kontrolka Timer1.
        /// </summary>
        /// <remarks>
        /// Pole generowane automatycznie.
        /// Aby wprowadzić zmiany, przenieś deklarację pola z pliku projektanta do pliku codebehind.
        /// </remarks>
        protected global::System.Web.UI.Timer Timer1;

        /// <summary>
        /// Kontrolka Panel2.
        /// </summary>
        /// <remarks>
        /// Pole generowane automatycznie.
        /// Aby wprowadzić zmiany, przenieś deklarację pola z pliku projektanta do pliku codebehind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.Panel Panel2;

        /// <summary>
        /// Kontrolka Label5.
        /// </summary>
        /// <remarks>
        /// Pole generowane automatycznie.
        /// Aby wprowadzić zmiany, przenieś deklarację pola z pliku projektanta do pliku codebehind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.Label Label5;

        /// <summary>
        /// Kontrolka TextBox1.
        /// </summary>
        /// <remarks>
        /// Pole generowane automatycznie.
        /// Aby wprowadzić zmiany, przenieś deklarację pola z pliku projektanta do pliku codebehind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.TextBox TextBox1;

        /// <summary>
        /// Kontrolka FiV1.
        /// </summary>
        /// <remarks>
        /// Pole generowane automatycznie.
        /// Aby wprowadzić zmiany, przenieś deklarację pola z pliku projektanta do pliku codebehind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.RequiredFieldValidator FiV1;

        /// <summary>
        /// Kontrolka ExV1.
        /// </summary>
        /// <remarks>
        /// Pole generowane automatycznie.
        /// Aby wprowadzić zmiany, przenieś deklarację pola z pliku projektanta do pliku codebehind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.RegularExpressionValidator ExV1;

        /// <summary>
        /// Kontrolka ExV2.
        /// </summary>
        /// <remarks>
        /// Pole generowane automatycznie.
        /// Aby wprowadzić zmiany, przenieś deklarację pola z pliku projektanta do pliku codebehind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.RegularExpressionValidator ExV2;

        /// <summary>
        /// Kontrolka Button1.
        /// </summary>
        /// <remarks>
        /// Pole generowane automatycznie.
        /// Aby wprowadzić zmiany, przenieś deklarację pola z pliku projektanta do pliku codebehind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.Button Button1;

        /// <summary>
        /// Kontrolka VSu1.
        /// </summary>
        /// <remarks>
        /// Pole generowane automatycznie.
        /// Aby wprowadzić zmiany, przenieś deklarację pola z pliku projektanta do pliku codebehind.
        /// </remarks>
        protected global::System.Web.UI.WebControls.ValidationSummary VSu1;
    }
}
